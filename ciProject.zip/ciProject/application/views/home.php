<div style="height:500px;width:100%; border:2px solid #000; float:left;"> Middle Area</div>
