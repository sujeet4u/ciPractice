<!DOCTYPE html>
<html>
    <head>
        <link href="<?php echo SITEURL . "/public_html/css/bootstrap.min.css"; ?>" rel="stylesheet" type="text/css"/>
        <!--<link href="<?php echo SITEURL . "/public_html/css/style.css"; ?>" rel="stylesheet" type="text/css">-->

    </head>
    <body style="background: #e6e6e6;">

        <div class="container">
            <div class="wrapper" style="margin-top: 20%;margin-left:25%;width:581px;">
                <div class=" col-sm-12 row form-group" style="background: #f8f8f8 ; color:#2f2f2f;border:solid 2px #f8f8f8;">

                    <div class="col-sm-12">
                        <h3>Log in to Admin Panel</h3>
                    </div>
                    <form enctype="multipart/form-data" method="post" action="" autocomplete="off">
                        <div class="col-sm-6 ">
                            <label class="control-label">User Name:</label>
                            <div><input type="text" name="txtUsername" value=""  class="input-sm"/></div>
                        </div>
                        <div class="col-sm-6 ">
                            <label>Password:</label>
                            <div><input type="password" name="txtpassword" value=""/></div>
                        </div>
                        <div class="col-sm-12">
                            <div class="col-sm-8" style="text-align:left;"><a href="Javascript:void(0)">Forgot your password?</a></div>
                            <div  class="col-sm-2" style="width:20%;margin-left:13%;"><input type="submit" name="btnlogin" value="Login" class="btn-warning" /></div>
                        </div>  

                    </form>


                </div>

            </div>

        </div>
        <footer>
            <script src="<?php echo SITEURL . "/public_html/js/bootstrap.min.js"; ?>" type="text/javascript"></script>
            <div>@copy 2017</div>
        </footer>
    </body>
</html>