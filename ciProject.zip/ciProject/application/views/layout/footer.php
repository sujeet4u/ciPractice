<div style="clear:both;"></div>
<div style="height:200px; width:100%; border:2px solid #000;">  Footer Area</div>