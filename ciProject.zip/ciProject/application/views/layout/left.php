<div style="height:500px; width:200px; border:2px solid #000; float:left;">  Left Area</div>
